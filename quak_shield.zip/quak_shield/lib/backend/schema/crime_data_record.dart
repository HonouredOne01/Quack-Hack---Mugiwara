import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CrimeDataRecord extends FirestoreRecord {
  CrimeDataRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "latitude" field.
  double? _latitude;
  double get latitude => _latitude ?? 0.0;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  double? _longitude;
  double get longitude => _longitude ?? 0.0;
  bool hasLongitude() => _longitude != null;

  // "severity" field.
  String? _severity;
  String get severity => _severity ?? '';
  bool hasSeverity() => _severity != null;

  void _initializeFields() {
    _latitude = castToType<double>(snapshotData['latitude']);
    _longitude = castToType<double>(snapshotData['longitude']);
    _severity = snapshotData['severity'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('crime_data');

  static Stream<CrimeDataRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CrimeDataRecord.fromSnapshot(s));

  static Future<CrimeDataRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CrimeDataRecord.fromSnapshot(s));

  static CrimeDataRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CrimeDataRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CrimeDataRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CrimeDataRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CrimeDataRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CrimeDataRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCrimeDataRecordData({
  double? latitude,
  double? longitude,
  String? severity,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'latitude': latitude,
      'longitude': longitude,
      'severity': severity,
    }.withoutNulls,
  );

  return firestoreData;
}

class CrimeDataRecordDocumentEquality implements Equality<CrimeDataRecord> {
  const CrimeDataRecordDocumentEquality();

  @override
  bool equals(CrimeDataRecord? e1, CrimeDataRecord? e2) {
    return e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude &&
        e1?.severity == e2?.severity;
  }

  @override
  int hash(CrimeDataRecord? e) =>
      const ListEquality().hash([e?.latitude, e?.longitude, e?.severity]);

  @override
  bool isValidKey(Object? o) => o is CrimeDataRecord;
}
