import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBllWT4E4w2XgCeqk5tG1-uWLYUOWfl6gk",
            authDomain: "quackathon-685ba.firebaseapp.com",
            projectId: "quackathon-685ba",
            storageBucket: "quackathon-685ba.firebasestorage.app",
            messagingSenderId: "556563725603",
            appId: "1:556563725603:web:b2e649ef4de104317e6096",
            measurementId: "G-JQYZQFD5L5"));
  } else {
    await Firebase.initializeApp();
  }
}
