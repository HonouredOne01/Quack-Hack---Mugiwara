// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/flutter_flow/lat_lng.dart'; // Use FlutterFlow's LatLng

Future<void> loadFakeCrimes() async {
  FFAppState().update(() {
    FFAppState().isLoading = true;

    // Ensure fakeCrimes is initialized with an empty list if it's null
    FFAppState().fakeCrimes ??= []; // This initializes it if it was null

    // Now safely assign values to fakeCrimes
    FFAppState().fakeCrimes = [
      LatLng(40.7128, -74.0060),
      LatLng(40.7138, -74.0070),
      LatLng(40.7148, -74.0080)
    ];

    FFAppState().isLoading = false;
  });
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
