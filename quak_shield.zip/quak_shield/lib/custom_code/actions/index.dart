export 'load_fake_crimes.dart' show loadFakeCrimes;
