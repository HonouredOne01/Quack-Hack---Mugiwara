import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<LatLng> _fakeCrimes = [];
  List<LatLng> get fakeCrimes => _fakeCrimes;
  set fakeCrimes(List<LatLng> value) {
    _fakeCrimes = value;
  }

  void addToFakeCrimes(LatLng value) {
    fakeCrimes.add(value);
  }

  void removeFromFakeCrimes(LatLng value) {
    fakeCrimes.remove(value);
  }

  void removeAtIndexFromFakeCrimes(int index) {
    fakeCrimes.removeAt(index);
  }

  void updateFakeCrimesAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    fakeCrimes[index] = updateFn(_fakeCrimes[index]);
  }

  void insertAtIndexInFakeCrimes(int index, LatLng value) {
    fakeCrimes.insert(index, value);
  }

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  set isLoading(bool value) {
    _isLoading = value;
  }

  List<LatLng> _crimeLocation = [];
  List<LatLng> get crimeLocation => _crimeLocation;
  set crimeLocation(List<LatLng> value) {
    _crimeLocation = value;
  }

  void addToCrimeLocation(LatLng value) {
    crimeLocation.add(value);
  }

  void removeFromCrimeLocation(LatLng value) {
    crimeLocation.remove(value);
  }

  void removeAtIndexFromCrimeLocation(int index) {
    crimeLocation.removeAt(index);
  }

  void updateCrimeLocationAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    crimeLocation[index] = updateFn(_crimeLocation[index]);
  }

  void insertAtIndexInCrimeLocation(int index, LatLng value) {
    crimeLocation.insert(index, value);
  }
}
